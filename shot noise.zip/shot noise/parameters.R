library(ggplot2)
library(gridExtra)
library(latex2exp)

data <- read.table("parameters.csv",sep=";",fill=TRUE,header = F)
BURNOUT <- 30000
NUMBER_OBS <- dim(data)[1]


kappa <- data.frame(dens = data[BURNOUT:NUMBER_OBS,3])
lambda_t <-data.frame(dens = data[BURNOUT:NUMBER_OBS,1])
lambda_f <- data.frame(dens = data[BURNOUT:NUMBER_OBS,2])



kappaPlot <- ggplot(kappa, aes(x = dens )) + geom_density(alpha = 0.7, size = 1.2)+labs(x =TeX("Estimated density of $\\kappa$")) + geom_vline(xintercept = 0.01, linetype="dotted", 
                                                                                               color = "blue", size=1.5) + theme_light() + theme(axis.title.y=element_blank(),
                                                                                                                                                 axis.text.y=element_blank(),
                                                                                                                                                 axis.ticks.y=element_blank()) +theme(axis.text=element_text(size=22), axis.title.x = element_text(size = 26))+ theme(plot.margin = unit(c(0,1,0,0), "lines"))
tLambdaPlot <- ggplot(lambda_t, aes(x = dens)) + geom_density(alpha = 0.7, size = 1.2) +labs(x =TeX("Estimated density of $\\lambda_t$")) + geom_vline(xintercept = 0.025, linetype="dotted", 
                                                                                                      color = "blue", size=1.5)+ theme_light() + theme(axis.title.y=element_blank(),
                                                                                                                                                   axis.text.y=element_blank(),
                                                                                                                                                       axis.ticks.y=element_blank()) +theme(axis.text=element_text(size=22), axis.title.x = element_text(size = 26)) + theme(plot.margin = unit(c(0,1,0,1), "lines"))
fLambdaPlot <- ggplot(lambda_f, aes(x = dens)) + geom_density( alpha = 0.7, size = 1.2) +labs(x =TeX("Estimated density $\\lambda_{\\phi}$")) + geom_vline(xintercept = 0.66, linetype="dotted", 
                                                                                                         color = "blue", size=1.5)+ theme_light() + theme(axis.title.y=element_blank(),
                                                                                                                                                          axis.text.y=element_blank(),
                                                                                                                                                          axis.ticks.y=element_blank()) +theme(axis.text=element_text(size=22), axis.title.x = element_text(size = 26))
PLOT_ROW_1 <- grid.arrange(kappaPlot, tLambdaPlot, fLambdaPlot,ncol = 3)



MAX_LENGTH <- max(count.fields("PopulationStats.csv", sep = ';'))
dataI <- read.table("PopulationStats.csv",sep=";",fill=TRUE,header = F, col.names = 1:MAX_LENGTH)
dataI <- dataI[1:1000,]
lastPopSize <- c()

for (i in 1:dim(dataI)[1]) {
  print(i)
  j <- 1
  while (j <= dim(dataI)[2] && !is.na(dataI[i,j])) j <- j +1
  j <- j -1
  lastPopSize <- c(lastPopSize, dataI[i,j])
}
lastPopSize <- data.frame(lastPopSize)
lastPopSize$iter <- 1:1000

sdPop <- c()
for (i in 1:dim(dataI)[1]) {
 sdPop <- c(sdPop, sd(dataI[i,], na.rm = T)) 
}

sdPop <- data.frame(sdPop)
sdPop$iter <- 1:1000

end_pop_plot <- ggplot() +geom_line(data = lastPopSize, aes(x = iter, y = lastPopSize), color = "black", size = 1.0) +xlab("Number of particles at the end \n of iteration")+ theme_light() + theme(axis.title.y=element_blank(),
                                                                                                                                                                                                 axis.ticks.y=element_blank()) +theme(axis.text=element_text(size=22), axis.title.x = element_text(size = 26))
sd_pop_plot <- ggplot() +geom_line(data = sdPop, aes(x = iter, y = sdPop), color = "black", size = 1.0) +xlab("Standard deviation of\nnumber of particles")+ theme_light() + theme(axis.title.y=element_blank(),
                                                                                                                                         axis.ticks.y=element_blank()) +theme(axis.text=element_text(size=22), axis.title.x = element_text(size = 26))
PLOT_ROW_2 <- grid.arrange(end_pop_plot, sd_pop_plot, ncol = 2)


PLOT <- grid.arrange(PLOT_ROW_1, PLOT_ROW_2, nrow = 2)

