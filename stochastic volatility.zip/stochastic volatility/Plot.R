library(gridExtra)
library(ggplot2)
pg <- read.table("PG_parameters.csv",sep=",",fill=TRUE,header = T)
ptpg <- read.table("PTPG_parameters.csv",sep=",",fill=TRUE,header = T)
BURNIN <- 5000
ptpg <- ptpg[BURNIN:dim(ptpg)[1],]
pg <- pg[BURNIN:dim(pg)[1],]


dat <- data.frame(dens = c(pg$X1, ptpg$X1) ,algorithm = rep(c("PGAS", "PTGAS"), each = dim(pg)[1]))

dat2 <- data.frame(dens = c(pg$X2, ptpg$X2) ,algorithm = rep(c("PGAS", "PTGAS"), each = dim(pg)[1]))

dat3 <- data.frame(dens = c(pg$X3, ptpg$X3) ,algorithm = rep(c("PGAS", "PTGAS"), each = dim(pg)[1]))


# Plot of densities of static parameters
dat <- ggplot(dat, aes(x = dens,  linetype = algorithm )) + geom_density(show.legend = FALSE, lwd = 1.2, alpha = 0.5)+labs(x ="density of phi")+ theme_light()  +theme(axis.text=element_text(size=20), axis.title.x = element_text(size = 26), axis.title.y = element_blank(), axis.text.y=element_blank(), axis.ticks.y=element_blank()) #+ theme(plot.margin = unit(c(3,3,3,3), "lines"))
dat2 <- ggplot(dat2, aes(x = dens,  linetype = algorithm)) + geom_density(show.legend = FALSE, lwd = 1.2) +labs(x ="density of sigma") + theme_light()+ theme(axis.title.y=element_blank(),                                                                                                                                                                            axis.ticks.y=element_blank())+theme(axis.text=element_text(size=20), axis.title.x = element_text(size = 26))
dat3 <- ggplot(dat3, aes(x = dens,  linetype = algorithm)) + geom_density(lwd = 1.2) +labs(x ="density of mu") + theme_light() + theme(axis.title.y=element_blank(),
                                                                                                                                                           axis.text.y=element_blank(),
                                                                                                                                                           axis.ticks.y=element_blank()) +theme(axis.text=element_text(size=20), axis.title.x = element_text(size = 26))+ theme(legend.text=element_text(size=26), legend.title = element_text(size=26))

PLOT_ROW_1 <- grid.arrange(dat, dat2, dat3,ncol = 3)



bacf <- acf(ptpg$X3, plot = FALSE, lag = 300)
bacfdf <- with(bacf, data.frame(lag, acf))
ptpg_acf <- ggplot(data = bacfdf, mapping = aes(x = lag, y = acf)) +
  geom_hline(aes(yintercept = 0)) +
  geom_segment(mapping = aes(xend = lag, yend = 0))+ theme_light() +labs(x ="Sigma acf (PTGAS)") +theme(axis.text=element_text(size=22), axis.title.x = element_text(size = 26), axis.title.y = element_text(size=26))


bacf <- acf(pg$X3, plot = FALSE, lag = 300)
bacfdf <- with(bacf, data.frame(lag, acf))
pg_acf <- ggplot(data = bacfdf, mapping = aes(x = lag, y = acf)) +
  geom_hline(aes(yintercept = 0)) +
  geom_segment(mapping = aes(xend = lag, yend = 0))+ theme_light() +labs(x ="Sigma acf (PGAS)") +theme(axis.text=element_text(size=22), axis.title.x = element_text(size = 26), axis.title.y = element_blank())


PLOT_ROW_2 <- grid.arrange( ptpg_acf, pg_acf, ncol = 2)

PLOT <- grid.arrange(PLOT_ROW_1, PLOT_ROW_2, nrow = 2)


